const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const ItemScheme = new Schema({
    email: Schema.Types.Mixed,
    password: Schema.Types.Mixed
});

module.exports = mongoose.model("item", ItemScheme);