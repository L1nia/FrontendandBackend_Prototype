function submitForm() {
    var username = document.getElementById("Имя пользователя").value;
    var password = document.getElementById("Пароль").value;
    var email = document.getElementById("Email").value;

    var data = "Имя пользователя: " + username + "\nПароль: " + password + "\nEmail: " + email;

    var file = new Blob([data], {type: "text/plain"});
    var a = document.createElement("a");
    var url = URL.createObjectURL(file);

    a.href = url;
    a.download = "registration_data.txt";
    document.body.appendChild(a);
    a.click();
    setTimeout(function() {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }, 0);
}