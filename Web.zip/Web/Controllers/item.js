exports.getItems = function getItems(request, response){
    response.render("items.hbs");
};


exports.postItem = async function(request, response){
    if(!request.body) return response.SendStatus(400);

    const email = request.body.email;
    const password = request.body.password;

    const item = new item({email: email, password: password});

    await item.save();
    response.redirect("/");
};
