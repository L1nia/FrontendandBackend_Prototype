exports.index = function index(request, response) {
  response.render("index.hbs");
};
exports.about = function about(request, response) {
  response.render("about.hbs");
};
exports.con = function con(request, response){
  response.render("conta.hbs");
};
exports.news = function news(request, response){
  response.render("news.hbs")
};
exports.sport = function sport(request, response){
  response.render("sports.hbs");
};
exports.items = function items(request, response){
  response.render("items.hbs");
};
exports.register = function register(request, response){
  response.render("register.hbs");
};




