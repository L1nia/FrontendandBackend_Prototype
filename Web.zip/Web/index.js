const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const MongoClient = require('mongodb').MongoClient;
const app = express();

const itemRouter = require("../Web/routes/itemRouter.js");
const HomeRouter = require("../Web/routes/HomeRouter.js");

app.set("view engine", "hbs");
app.set("views", "pages");
app.use('/css', express.static('./css')); 
app.use('/js', express.static('./js'));
app.use('/img', express.static('./img'));
app.use(express.urlencoded({extended: false}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const url = "mongodb://localhost:27017";
const port = 43030;
const DBName = "person";

app.use("/items", itemRouter);
app.use("/", HomeRouter);

//app.post('/register', async (req, res) => {
//  const { username, password, email } = req.body;

//  try {
//    const client = await MongoClient.connect(url);
//    const db = client.db(DBName);
//    const collection = db.collection('users');
//    await collection.insertOne({ username, password, email });
//    console.log('Пользователь зарегистрирован');
//    res.send('Вы успешно зарегистрировались!');
//    await client.close();
//  } catch (err) {
//    console.log(err);
//  }
// });

async function main() {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/' + DBName);
    app.listen(port);
    console.log("Server turned on");
  } catch (err) {
    console.log(err);
  }
}

async function connectToMongoDB() {
  let client;
  try {
  client = await MongoClient.connect(url);
  const db = client.db(DBName);
  const result = await db.command({ ping: 1 });
  console.log("Подключение к MongoDB успешно установлено");
  console.log(result);
  } catch (err) {
  console.log("Возникла ошибка при подключении к MongoDB");
  console.log(err);
  } finally {
  await client.close();
  console.log("Подключение к MongoDB закрыто");
  }
  }

async function checkDB() {
  let client;
  try {
    client = await MongoClient.connect(url);
    const db = client.db(DBName);
    const isDBExists = await db.admin().listDatabases({ nameOnly: true });
    const isCollectionExists = await db.listCollections().toArray();

    let isDBCreated = false;
    let isCollectionCreated = false;

    for (let i = 0; i < isDBExists.databases.length; i++) {
      if (isDBExists.databases[i].name === DBName) {
        isDBCreated = true;
        break;
      }
    }

    for (let i = 0; i < isCollectionExists.length; i++) {
      if (isCollectionExists[i].name === "users") {
        isCollectionCreated = true;
        break;
      }
    }

    if (!isDBCreated) {
      throw new Error(`Database ${DBName} is not created`);
    }

    if (!isCollectionCreated) {
      throw new Error("Collection 'users' is not created");
    }

    console.log("Database and Collection are created");
  } catch (err) {
    console.log(err);
  } finally {
    await client.close();
  }
}

async function run() {
  await connectToMongoDB();
  await checkDB();
}

run();

//async function startApp() {
//  await Promise.all ([main()]);
//}

//startApp().catch(console.error);


  
main();  

process.on("SIGINT", async () => {
  await mongoose.disconnect();
  console.log("Web turned off");
  process.exit();
});

const fs = require('fs');

fs.readFile('data.txt', 'utf8', (err, data) => {
  if (err) {
    console.error(err);
    return;
  }

  console.log(data);
});
