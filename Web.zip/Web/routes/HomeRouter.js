const express = require("express");
const homeController = require("../Controllers/home.js")
const HomeRouter = express.Router();

HomeRouter.use("/about", homeController.about);
HomeRouter.use("/contacts", homeController.con);
HomeRouter.use("/news", homeController.news);
HomeRouter.use("/sports", homeController.sport);
HomeRouter.use("/items", homeController.items);
HomeRouter.use("/register", homeController.register);
HomeRouter.use("/", homeController.index);


module.exports = HomeRouter;