const express = require("express");

const itemController = require("../Controllers/item.js");
const itemRouter = express.Router();

itemRouter.use("/items", itemController.getItems);
itemRouter.use("/postitem", itemController.postItem);

module.exports = itemRouter;