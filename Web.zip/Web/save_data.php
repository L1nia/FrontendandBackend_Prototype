<?php
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    // Проверка получения данных
    echo "username: " . $username . ", password: " . $password . ", email: " . $email;

    $data = "Имя пользователя: " . $username . "\n";
    $data .= "Пароль: " . $password . "\n";
    $data .= "Email: " . $email . "\n";

    // Открываем файл для записи
    $file = fopen("data.txt", "w");

    // Записываем данные в файл
    fwrite($file, $data);

    // Закрываем файл
    fclose($file);
?>